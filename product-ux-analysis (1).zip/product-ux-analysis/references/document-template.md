# 文档模板：竞品体验分析

这是从四篇黄金范例（Moxt / NotebookLM / Tomoro / Tbox）提炼的固定骨架。**骨架、章节顺序、表格列名集合、callout emoji 体系是固定的**，分析内容自由发挥。用 `lark-doc` 的 XML 格式生成。

> **结构化与易读性是硬要求**：必须保留下文规定的两类表格（核心功能类 / 亮点类，列名从固定集合里按形态选），不要拆成散段落；**每段界面/交互描述旁要有对应图，且必须把图嵌进对应的表格单元格里（文字 + 图同格）**（能动则 GIF，**且图要密**——前/中/后或多状态触点配 3–5 张，并排用 `<grid>`）。**图文密度按产品体量分级判定（表格数 / 图片总数 / 内嵌图数 / 带图单元格），统一以 `analysis-framework.md`「图文密度自检」为准——那是全文唯一口径；重产品对齐黄金范例量级，轻产品以"每个真实亮点都配齐图"为准，⛔ 不为凑数硬塞。** 体验设计主题按"由浅至深"排序、**命名第一标准是一看就懂、有人味儿（大白话/带画面感优先，别强行套"XX 化"）**；引言之后直接进入 `# 产品定位`（⛔ 不放"关键要点 / TL;DR"概览段，已废弃）、产品定位的"发展时间线"用**画板可视化产品发展史（纵向带日期时间线，非功能流程）**、结尾落到 `# 设计启发`。这些是文档可评审、易读的根本。

---

## 整体骨架（按顺序）

```
<title>{产品名}：{一句话定位/记忆点，可加引号}</title>

<blockquote>
{引言：为什么分析这个产品 / 背景 / 与自身业务的关联——blockquote 只用于"开场引出话题"这一段}
</blockquote>

{⛔ 不要写"关键要点 / TL;DR"概览段——已废弃。引言 blockquote 之后直接进入正文章节}

<callout emoji="🌠">{首屏一句话核心洞察，可选}</callout>

# 产品定位
# 核心功能  /  # 亮点功能      ← 简单产品用「核心功能」单层；复杂/多智能体用「亮点功能」+ ##/### 分层
# 体验设计      ← 重中之重
# 设计启发      ← 把前面的设计洞察逐条转写为可行动的设计主张（2×2 callout）
（结尾 blockquote / callout：总体评价 / 设计哲学升华 / 体验链接）
# 参考资料      ← 固定收尾章节：把本文参考的外部资料按序列出
```

---

## 一、引言（标题下方）

- **标题（要引人注目、且多样化，别套同一个模子）**：核心是 `产品名：一句话记忆点`，但**记忆点的写法要换着来**，让人一眼想点进去。可选的几种笔法（轮换，别每篇都同一种）：
  - **比喻/画面感**：`Moxt：一个 "给 AI 住的办公室"`、`Kuse：一块给 AI 用的「无限画布」`
  - **反差/悬念**：`NotebookLM：把一堆资料喂进去，它比你更懂你的资料`
  - **数字/战绩钩子**：`Kuse：0 融资、60 天做到 1000 万 ARR 的 AI 工作台`
  - **金句/Slogan 直引**：`Tomoro："Chaos In, Genius Out" 是怎么做到的`
  - **一句话范式转变**：`Tbox：当 Agent 不再是"对话框"，而是"会交活的同事"`
  > ⚠️ 别每篇都用同一种套路（尤其别都用"XX：一个……的产品"这种平铺）。先想"这个产品最抓人的那一点是什么"（战绩 / 反差 / 比喻 / 金句），再据此选笔法。
  > 🚫 **标题也是"最后才写"，⛔ 不许先拍一个好听的大标题再倒推全文（和体验设计主题同理，见 `analysis-framework.md`「强制两段式」）。** 上面这些 `Moxt / Kuse / Tbox …` 是**别篇产品的标题，只示范笔法、不是你的候选池**——⛔ 套任何一条到你的产品都不合格。正确顺序：**先把全文分析（定位 + 核心功能 + 体验设计）写完 → 回头问"这个产品最抓人的那一点到底是什么" → 据此现起标题。** ❌ 照搬翻车：开工前就先定 `XX：一个给 AI 用的无限画布`，再硬把内容往这个调性上凑。自检：把你的标题里的产品名换掉，它若"换谁都成立"，就是空话/套范例，回去重写。
- **引言 blockquote（开头别千篇一律"最近刷到"）**：交代**为什么分析它**，要诚恳、第一人称、有动机；但**开场方式要多样化**，不要每篇都以"最近在 X 上刷到"开头，那样很死板。可轮换的几种开场：
  - **从一个问题/好奇切入**：`一个 0 融资的产品凭什么 60 天做到 1000 万 ARR？我更好奇的是它怎么把"乱资料进、成品出"设计成让人愿意自发安利的体验。`
  - **从自身业务痛点切入**：`我们在做 Data Agent 时一直纠结"过程要不要给用户看"，于是想看看把这件事做到极致的产品是怎么处理的。`
  - **从一个具体场景切入**：`上周帮同事整理一份调研，把十几个 PDF 丢进去那一刻，我第一次觉得"AI 工作台"这个词是成立的。`
  - **从行业趋势/对比切入**：`当大多数 AI 产品还停留在"一问一答"，有几个产品已经在重新定义"工作台"长什么样——这是其中之一。`
  - **从口碑/推荐切入**（即"最近刷到"那一类，**可用但别每篇都用**）：`最近被好几个设计师朋友安利……`
  > **blockquote（引用格式）只用于这一段开场引题**，不要拿它装结论或要点。
- ⛔ **不要写"关键要点 / TL;DR"概览段（已废弃）**：引言 blockquote 之后直接进入 `# 产品定位`，不要再在开头摆一段逐章结论清单。
- **首屏 callout（可选）**：用一个对比/比喻点出产品的范式转变。

> 引用规范：引用某条来源信息时，`[[标题]](url)` 放在**句末、句号之前**，且**仅对取自该来源的事实/引述**这么标；开场引题句、过渡句、导航文字不加引用，URL 本身即答案（体验链接/下载地址）时用普通 `[文本](url)`。

> 范例（Moxt）：
> ```
> <callout emoji="🌠" background-color="light-purple" border-color="purple">
> <p align="center">一个人问，一个 AI 答</p>
> <p align="center">👇</p>
> <p align="center">**一个团队 / 人 + 一组 Agent + 一套流程 + 一套共享资产**</p>
> </callout>
> ```
> ⚠️ 内容**居中对齐**（每行 `<p align="center">`），并给一个**底色**（见「排版规范」第 2、3 条）。

---

## 二、# 产品定位

结构：
1. **一句话定位**：谁出的 + 面向什么场景/用户 + 用什么方式 + 解决什么。把核心价值**加粗**。
2. **英文 slogan**（斜体，若产品有）：`*"a workspace designed for agents first..."*`
3. **定位四要素（必备，缺一不可）**：定位章节不能只有一句话定位，还要交代清楚下面四项——这些是判断"它给谁、做多大、走到哪、用在哪"的基本盘，**信息靠联网搜官网/资讯/访谈补全**，按 `[[标题]](url)` 行内引用来源：
   - **核心用户**：主要面向谁（个人/团队/企业？什么角色？什么行业？）。
   - **用户规模**：注册量 / DAU / 付费客户数 / 估值融资等可得的体量信号（搜得到就写，写明出处；搜不到就标"暂未公开"）。
   - **产品发展时间线**：前身/起源（如有）/ 成立 / 上线 / 关键版本 / 重大功能更新 / 融资 / 市场规模变化等里程碑，体现演进节奏。⚠️ **这一项不在表格里铺文字，而是用画板（whiteboard）可视化**——四要素表里只放一句引子，把**产品发展史**画成**纵向带日期的时间线画板**紧跟首屏图之后（⛔ 不是功能使用流程；做法见本节末「发展时间线画板」）。
   - **应用场景**：典型用在什么任务上（如调研、写作、数据分析、客服…），最好给 2–4 个具体场景。
4. **产品首图（固定 = 官网/落地页首屏）**：本章节配图**固定截取产品官网/落地页的 hero 第一屏**（含 Logo、Slogan、主视觉），不要用登录后的内页替代。可用 `<grid>` 双列放该首屏的 1–2 张（如首屏整体 + 主视觉特写）；若首屏有轮播/动效，优先放 GIF。
5. **发展时间线画板（固定）**：首图之后放一个里程碑画板，把"发展时间线"做成**自上而下、带日期的纵向产品发展史**可视化（见本节末「发展时间线画板」详解）。

```xml
# 产品定位

由{公司}推出的{品类}，通过**{核心方式}**，{解决什么}。

*"{英文 slogan}"*

<table><colgroup><col width="200"/><col width="600"/></colgroup>
<thead><tr><th background-color="light-gray">维度</th><th background-color="light-gray">说明</th></tr></thead>
<tbody>
<tr><td><b>核心用户</b></td><td>{面向谁：角色/行业/个人或团队或企业} [[来源]](url)</td></tr>
<tr><td><b>用户规模</b></td><td>{注册量/DAU/付费数/融资估值，写明出处；无则"暂未公开"} [[来源]](url)</td></tr>
<tr><td><b>发展时间线</b></td><td>{一句引子，如"从 X 周开发上线到持续迭代，下方画板按时间梳理产品发展史"；前身/发布/重大更新/规模变化等里程碑交给下方画板} [[来源]](url)</td></tr>
<tr><td><b>应用场景</b></td><td>{2–4 个典型任务场景}</td></tr>
</tbody></table>

<grid>
<column width-ratio="0.500000">{首图1}</column>
<column width-ratio="0.500000">{首图2}</column>
</grid>

<whiteboard type="blank"></whiteboard>   <!-- 发展时间线画板：create 后取 token，再用 SVG 纵向时间线（前身/发布/重大更新/规模变化）填充，见下 -->
```

### 发展时间线画板（经实测验证，务必照做）

> "发展时间线"画板有两件事最容易做错：**画什么内容**、**画成什么形态**。先把这两点对齐，再看怎么落地。

#### 内容：画的是"产品发展史"，不是功能流程

按时间顺序铺这几类里程碑（**有则写、无则跳过、搜不到标"暂未公开"**）：

1. **前身 / 起源** —— 这个产品从什么演变而来（如 NotebookLM 的前身是实验项目 "Project Tailwind"）。**若确无前身就不写**这一节点。
2. **正式发布 / 上线** —— 产品何时公开上线、初始定位是什么。
3. **重大功能更新 / 范式升级** —— 关键版本、能力跃迁、定位转变（可多个节点）。
4. **市场规模变化** —— 融资、注册量 / DAU、付费客户、估值等体量信号的演进（搜得到就写、写明出处）。

> ⛔ **反例**：把"对话 → 执行 → 产出产物"这种**功能使用流程**画成时间线——那是功能拆解，不是发展史。时间线的横轴是**日历时间**，不是操作步骤。

#### 形态：纵向、带日期的时间线（对齐参考文档 NotebookLM 画板）

每个节点 = **彩色圆圈里一个 emoji 图标** + **加粗日期/阶段标题**（如"2023 年 5 月""2025 年 · 起步"）+ **一句描述**；节点之间用**虚线竖轴**串联，自上而下按时间推进。

> ⚠️ whiteboard 渲染器**不支持 mermaid `timeline` 类型**；而 `flowchart LR` 只能画横向方块流程，**塞不下日期与整句描述、形态也不对**。要得到这种"纵向 + 日期 + 描述"的形态，**用 SVG 路线手绘**（或 `lark-whiteboard` 的 `scenes/milestone.md` 里程碑场景），**不要用 flowchart**。

#### 落地三步

**Step A — 骨架里放空画板块**：在 `+create` 的 XML 中、首屏图之后写 `<whiteboard type="blank"></whiteboard>`。

**Step B — create 后取画板 token**：`docs +fetch --doc <docid>` 把文档回拉，从里面正则捕获画板 token。⚠️ fetch 的 markdown 里引号被 JSON 转义成 `\"`，所以正则要**匹配到 `\` 或 `"` 即止**——这是最易翻车的一步，直接复制下面的函数，别手搓正则：

```python
import re, subprocess
def grab_board_token(cli, docid):
    md = subprocess.run(["bash", cli, "docs", "+fetch", "--doc", docid],
                        capture_output=True, text=True).stdout
    # token=\"xxx\" 或 token="xxx" 两种转义形态都兜住：碰到 \ 或 " 即止
    m = re.search(r'<whiteboard[^>]*?token=\\?"([^"\\]+)', md)
    assert m, "❌ 没在文档里找到画板 token——确认 create 的 XML 里有 <whiteboard type=\"blank\">"
    return m.group(1)
```

**Step C — 写成 SVG 纵向时间线**：虚线竖轴 + 每节点（圆圈 emoji + `<text>` 加粗日期 + `<text>` 描述）。先 `--check` 自检（textOverflow / nodeOverlap 须为 0），再转 OpenAPI、取 `data.result` 写入：

```bash
# timeline.svg 示例骨架（纵向，节点自上而下）
#   <line .../>                                   <!-- 虚线竖轴 dasharray="3,6" -->
#   <circle cx=48 cy=60 r=26 fill="#E8EBFA"/>     <!-- 节点圆圈 -->
#   <text x=48 y=70 ...>🐣</text>                 <!-- 圆圈内 emoji -->
#   <text x=100 y=50 font-weight=bold>2023 年 7 月 · 前身 Project Tailwind</text>
#   <text x=100 y=80 font-size=15>实验项目，验证"喂资料给 AI、就资料问答"的形态。</text>
#   ...（每个里程碑一组：circle + emoji + 加粗日期 + 描述）
WBCLI=<lark-whiteboard>/scripts/whiteboard-cli.sh
CLI=<lark-doc>/scripts/lark-cli.sh
# 0) 渲染自检：textOverflow / nodeOverlap 必须为 0
$WBCLI -i timeline.svg -f svg --check
# 1) SVG -> openapi，取其 data.result（即 {nodes:[...]}）
$WBCLI -i timeline.svg -f svg --to openapi --format json \
  | python3 -c 'import sys,json;print(json.dumps(json.load(sys.stdin)["data"]["result"],ensure_ascii=False))' \
  | $CLI whiteboard +update --whiteboard-token <tok> --source - --input_format raw --overwrite --idempotent-token <时间戳>
# 返回 {"ok":true,"data":{"created_node_ids":...}} 即成功
# 2) ⚠️ 注入后立即数节点核对（成败唯一判据，别看 _notice）
$CLI whiteboard +query --whiteboard-token <tok> --output_as raw --format json \
  | python3 -c 'import sys,json;print("实得节点数=",len(json.load(sys.stdin)["data"]["nodes"]))'
# 实得 ≈ SVG 转 openapi 的节点数 → 成功；为 0 → 没写进去；翻倍 → 叠加了，删板重做
```

> ⚠️ **画板注入只能往一块全新的空画板做一次（幂等性，最易翻车）**：`whiteboard +update --overwrite` 实测是**追加**而非整体替换——SVG 时间线会被拆成上百个图元节点（实测一条 6 里程碑时间线 ≈170–180 个节点），**对同一块画板跑两次就会把整条时间线叠两份、严重错位**。所以：
> 1. **注入前确认画板为空**：刚 create 出来的 `<whiteboard type="blank">` 是空的，直接注入；若是重试场景，先 `whiteboard +query --whiteboard-token <tok> --output_as raw --format json` 看 `data.nodes` 是否为空，确认里面没有残留节点。
> 2. **注入失败不要盲目重跑**：`lark-cli update` 在 Mira 里被禁用、返回的 `_notice`（"skill 未安装"之类）是**无害噪声**，**不能据此判断成败**——要看 `data.nodes` 节点数（用上面的 `+query`）：等于 SVG 转 openapi 的节点数就是成功了，别再跑第二遍；为 0 才是真没写进去，修好再注。
> 3. **要重做就换新画板**：若第一次注入出了脏数据，最干净的办法是删掉该画板块、重新 create 一个空 `<whiteboard>` 再注入一次，而不是在脏画板上再 `--overwrite`。
> 4. `--idempotent-token` 用**当次时间戳**，仅用于防止同一请求因重试被服务端重复执行，**不能**阻止你"换个 token 再注入一遍"造成的叠加——叠加的防护靠上面三条。

> SVG 路线约束（务必遵守）：禁用 `<radialGradient>/<filter>/<pattern>/<clipPath>/<mask>`（渲染器不支持、会破图）；文字一律用 `<text>`/`<tspan>`（内置 Noto Sans SC）；可用形状 rect/circle/ellipse/polygon/line/polyline/path。CJK≈1em、拉丁≈0.6em 预留宽度，避免文字溢出。
> 详细画板能力（查询/导图/甘特/SVG/DSL 里程碑场景）参考 `lark-whiteboard` skill。"取 token → SVG 转 openapi → whiteboard +update" 这条完整流水线已在上面「落地三步」给出，照做即可——自行用 Python 写脚本，不要依赖任何特定会话里的旧脚本。

---

## 三、# 核心功能 / # 亮点功能

两段式：先**俯瞰**，再**逐模块拆解**。章节名按产品复杂度选：

- **简单产品**（单一智能体/单一主流程）：用 `# 核心功能`，下面直接一张 `核心功能|描述` 表。
- **复杂产品**（多智能体、多入口、多子小组）：用 `# 亮点功能`，下设 `##` 二级（如 `## 超级智能体（多智能体）` / `## 对话智能体（单智能体）`），必要时再 `###` 三级（如 `### 数据分析小组` / `### 报告小组`），每层挂自己的表。

### 表格列名集合（固定，按形态选用，不要自创）

| 用途 | 表头 | 何时用 |
|---|---|---|
| 模块拆解（默认） | `核心功能` \| `描述` | 大多数核心功能表 |
| 模块拆解（多智能体子小组下） | `功能` \| `描述` | h2/h3 分层后的子表 |
| 流程/场景拆解 | `场景` \| `描述` | 按"整体流程/待提升点"等场景维度组织时 |
| 体验亮点（默认） | `亮点体验` \| `描述` | 体验设计章节亮点表 |
| 体验亮点（做法×触点） | `亮点做法` \| `触点及描述` | 想强调"具体做法 + 落在哪个触点"时 |

### 3.1 四大能力概览（固定 2×2 callout）

用 4 个 callout 概括产品最核心的四组能力，**emoji 固定用 📂 🎵 🪐 👥**（保持团队认知一致），2×2 grid 排布。每个 callout：**加粗小标题 + 一句话说明**。⚠️ 四个 callout 各配一种底色（blue/green/orange/purple），不要同色（见「排版规范」第 3 条）。

```xml
<grid>
<column width-ratio="0.500000"><callout emoji="📂" background-color="light-blue" border-color="blue">**{能力1标题}**
{说明}</callout></column>
<column width-ratio="0.500000"><callout emoji="🎵" background-color="light-green" border-color="green">**{能力2标题}**
{说明}</callout></column>
</grid>
<grid>
<column width-ratio="0.500000"><callout emoji="🪐" background-color="light-orange" border-color="orange">**{能力3标题}**
{说明}</callout></column>
<column width-ratio="0.500000"><callout emoji="👥" background-color="light-purple" border-color="purple">**{能力4标题}**
{说明}</callout></column>
</grid>
```

可在概览后插一张整体界面截图。

### 3.2 模块拆解表（列名从固定集合选：核心功能 | 描述 等）

一张两列表格，**左列模块名（加粗），右列详述**。这是功能的"事实层"，客观描述每个模块做什么、怎么用，**配大量截图（图要密）**。

- 有状态的流程（如对话）要按 **对话前 / 对话中 / 对话后**（或 提问前/中/后、规划/执行/产物）分层，用 `<b>` 小标题 + `<hr/>` 分隔。
- 描述用有序/无序列表，**截图用 `<grid>` 双列/三列**穿插在列表项之间，一个触点配多张图体现全过程，GIF 优先体现操作过程。
- **🌟 行内标记**：在右列某条要点末尾直接加 `🌟`，标出该模块里"杀手级"的小细节（如 `提示词自动轮播 🌟`、`用户可原位编辑大纲，失焦后自动执行 🌟`），方便评审快速定位亮点。
- **左列编号**用 `<ol><li seq="1"><b>模块名</b></li></ol>`，右列首行可用 `<p><b>一句话该模块的核心价值</b></p>` 起头，再展开列表。

```xml
<table><colgroup><col width="200"/><col width="600"/></colgroup>
<thead><tr><th>核心功能</th><th>描述</th></tr></thead>
<tbody>
<tr><td><b>{模块名}</b></td><td>
<b>对话前</b>
<ol><li seq="1">{要点}</li><li>{要点}</li></ol>
{此处插 grid 双列截图}
<hr/><br/>
<b>对话中</b>
...
</td></tr>
</tbody></table>
```

> 列名从固定集合选（`核心功能|描述` / `功能|描述` / `场景|描述`），不要自创。

---

## 四、# 体验设计（重中之重）

这是整篇文档的价值核心。**不是罗列功能，而是提炼"好设计点"**：每个亮点说清**设计手段 → 设计目的 → 深度洞察**。

结构：把观察到的亮点**归纳成 2–4 个主题**，每个主题是一个 `##` 二级标题。**主题命名第一标准是一看就懂、有人味儿**——大白话 / 带画面感的短句优先（如「AI 当着你的面查资料、写文件」「把 Agent 当同事来招」），或 `{体验特质}的{设计领域}`（如「克制清晰的三栏布局框架」「快人一步的场景联动」）；`{设计特质}化`（如「Agent 人格化」「执行过程白盒化」）只在"…化"之后那个词本身就好懂时才用，⚠️ **别为显专业强行套"XX 化"**（"上下文智能化""转换可控化"这类读者看不懂的就是反面教材）。总之要有观点、有概括力，不要干巴巴的功能名，也不要谁都看不懂的黑话。每个二级标题下：

1. **一个洞察 callout**（emoji 用 💡 或 🔗）：这是灵魂。**不能只描述现象，要点出设计意图和可借鉴之处**。加粗一句话主旨 + 展开解释。
2. **一张亮点表**：列名二选一——默认 `亮点体验 | 描述`；想强调"做法 + 落在哪个触点"用 `亮点做法 | 触点及描述`。左列编号亮点（加粗）+ 可加 blockquote 点睛金句；右列详述 + 图文/GIF（图要密）+ 🌟 标杀手细节。
   - ⚠️ **右列（描述/触点列）的每一条都必须配对应的截图/GIF 嵌在同一单元格里**——体验设计是最需要"看图说话"的章节，光有文字读者根本不知道你在讲哪个界面、哪个细节。**凡描述某界面/交互/状态的文字，旁边就要有那张图坐实**；多状态触点（前/中/后、空态/加载/结果）并排用 `<grid>` 放多张。**只有文字、没有配图的体验描述，视为不合格，回去补图。**

```xml
# 体验设计

## {主题1：一看就懂、有人味儿的标题，如"AI 当着你的面查资料、写文件"}

<callout emoji="💡" background-color="light-blue" border-color="blue">
**{一句话设计主旨}**
{展开：用了什么手段、解决什么问题、为什么值得借鉴}
</callout>
<!-- ⚠️ 各主题的洞察 callout 轮换底色（blue→orange→purple→green…），相邻主题不同色，见「排版规范」第 3 条 -->

<table><colgroup><col width="200"/><col width="600"/></colgroup>
<thead><tr><th>亮点做法</th><th>触点及描述</th></tr></thead>
<tbody>
<tr><td>
<ol><li seq="1"><b>{亮点做法名}</b></li></ol>
<blockquote><p>{点睛金句：这个设计的妙处一句话}</p></blockquote>
</td><td>
<ul><li>{具体怎么做的} 🌟</li></ul>
{⚠️ 必配：截图 / GIF 嵌进本单元格——这一条讲的界面/交互长什么样，要有图坐实；多状态用 <grid> 并排多张，能密则密}
</td></tr>
</tbody></table>
```

> **洞察 callout 的好坏对照**（详见 analysis-framework.md）：
> - ❌ 弱："新手引导做得很流畅，有换装、起名等步骤。"（只描述现象）
> - ✅ 强："换装头像 → 起名建队 → 步骤引导 → 快速开始，把'理解一个全新范式'拆成可完成的几小步，新概念在流程中自然透出，而非一次性灌输。"（手段+目的+洞察）

左列的 blockquote 金句也很关键，是对该亮点设计价值的高度凝练，例："把'配置一个 Agent'翻译成'招一位同事'，极大降低心理门槛"。

---

## 五、# 设计启发（把洞察变成可行动的设计主张）

体验设计章节是"拆解它好在哪"，这一章是"**所以我们能在设计上学什么**"——把前面的设计洞察，逐条转写成**可行动的设计主张**。这是评审里最被关注的"so what"。

- 章节名固定用 **`# 设计启发`**（不要写成"对 XX 的启发/对 Data Agent 的启发"等带具体产品名的形式）。
- 用 **2×2 callout**（emoji 仍用 📂 🎵 🪐 👥）或一组要点。**每条 = 一句可落地的设计主张**（祈使句、能直接指导设计动作），后面跟一句"为什么/怎么用"。
- 重点是"把洞察变成主张"：不是复述竞品功能，而是给出"我们应该这样设计"的明确做法。

```xml
# 设计启发

<grid>
<column width-ratio="0.5"><callout emoji="📂" background-color="light-blue" border-color="blue"><p><b>{可行动的设计主张1（祈使句）}</b></p><p>{为什么 / 怎么落到设计}</p></callout></column>
<column width-ratio="0.5"><callout emoji="🎵" background-color="light-green" border-color="green"><p><b>{可行动的设计主张2}</b></p><p>{为什么 / 怎么落到设计}</p></callout></column>
</grid>
<grid>
<column width-ratio="0.5"><callout emoji="🪐" background-color="light-orange" border-color="orange"><p><b>{可行动的设计主张3}</b></p><p>{为什么 / 怎么落到设计}</p></callout></column>
<column width-ratio="0.5"><callout emoji="👥" background-color="light-purple" border-color="purple"><p><b>{可行动的设计主张4}</b></p><p>{为什么 / 怎么落到设计}</p></callout></column>
</grid>
```

> 设计主张写法对照：
> - ❌ 偏功能复述："Moxt 会自动把当前文件设为上下文。"
> - ✅ 可行动主张："**让用户当前聚焦的对象（表/看板/SQL）默认成为 AI 上下文，并显式可解除**——省去手动指定数据源，又把'AI 用了哪份数据'摊在明面。"

---

## 六、结尾收束

用一个 blockquote 或 callout 收束，升华到**设计哲学层面**的整体评价——这个产品最值得记住的一点是什么。**若有公开体验入口，附上体验链接**方便读者自行上手。

```xml
<callout emoji="🏁" background-color="light-red" border-color="red">
{总体评价：它的可贵之处 / 设计哲学 / 对行业或自身的启发；若收尾要点出短板/提醒，用 light-red 凸显}
</callout>

<blockquote><p>当然 {产品名} 还有很多值得体验的功能：…… 体验链接：{url}</p></blockquote>
```

> 范例（Moxt）："Moxt 的可贵之处，不在于它已经做得多好多完善，而在于它**认真地把'如果工作空间是为 AI 而非为人设计，会长成什么样'这个问题，做成了一个可以上手体验的产品**。"

---

## 七、# 参考资料（固定收尾章节）

文档**最后固定加一个 `# 参考资料` 章节**，把你写这篇分析时**真正参考过的外部资料按序陈列**——官方博客 / 官网 About、媒体报道 / 评测、创始人访谈 / 播客、行业分析文章等。这让分析有据可查、读者可顺藤摸瓜。

- **只列真正参考过的外部来源**，不要把"产品自身界面/你自己的截图/生成的文档"当参考资料（那是你的一手观察，不是外部引用）。
- **按引用先后或重要性排序**，用有序列表，每条 = `[文章/页面标题](url)` + 可选一句话说明它提供了什么（如"创始人访谈，交代了从'设计 Agent'转向的过程"）。
- 与正文行内 `[[标题]](url)` 引用**呼应**：正文里句末标注过的来源，这里应当能找到对应条目（去重后汇总）。
- 这里的链接**是内容本身（资料清单），用普通 `[标题](url)`**，不要用行内引用的 `[[标题]](url)` 双括号格式。

```xml
# 参考资料

<ol>
<li seq="1">[At 21, he bootstrapped Kuse.ai to $10M ARR in 60 days](https://venturebeat.com/...) —— VentureBeat 报道，提供增长数据与商业模式背景。</li>
<li>[Better AI-Human Collaboration — Kuse](https://www.kuse.ai/about) —— 官网 About 页，用户规模与团队信息来源。</li>
<li>[How to Master Context Engineering — Aakash Gupta](https://www.news.aakashg.com/...) —— 创始人访谈，交代产品从"设计 Agent"转向横向知识型 AI 的过程。</li>
</ol>
```

> ⚠️ 若某篇分析确实没参考任何外部资料（纯界面走查），可省略本章；但只要正文出现过 `[[标题]](url)` 行内引用，就**必须**有对应的 `# 参考资料` 汇总。

---

---

## 排版规范（经实测验证，务必照做）

这几条是用户反复强调、最影响"成品观感"的格式细节，每篇都要做到：

1. **表格列宽 = 1:3，且撑满飞书文档默认宽度（≈800px）。** 两列表格的 `<colgroup>` 不要留空 `<col/><col/>`（那样两列会均分、第一列过宽浪费、第二列图文挤），也不要太窄（如 `120/430` 合计才 550px，撑不满文档默认宽度、右侧留一条空白很难看）。改用显式像素宽，按 **1:3 比例撑满约 800px**——第一列窄、第二列宽：
   ```xml
   <table><colgroup><col width="200"/><col width="600"/></colgroup>
   ```
   合计 800px 正好贴合飞书文档默认正文宽度：第二列足够放图文、又不会超出可见范围出横向滚动条。**定位四要素表、核心功能表、体验设计表都套同一组列宽**，保持全篇一致、整齐撑满。

2. **头部"变化总结"高亮块内容居中对齐。** 引言后那个一句话核心洞察 callout（emoji 🌠），里面每一行都用 `<p align="center">` 包起来，让对比/比喻居中、更像"标语"：
   ```xml
   <callout emoji="🌠" background-color="light-purple" border-color="purple">
   <p align="center">{旧范式：一句话}</p>
   <p align="center">👇</p>
   <p align="center">**{新范式：一句话}**</p>
   </callout>
   ```
   （`align` 适用于 callout 内的 `p / h1-h9 / li`。）

3. **高亮块多换颜色，别整篇一个色。** callout 全篇统一一种底色读起来很枯燥——要按"色轮"给不同 callout 配不同 `background-color` + `border-color`，让版面有节奏。可用色：`light-blue/blue`、`light-green/green`、`light-orange/orange`、`light-purple/purple`、`light-red/red`、`light-yellow/yellow`。建议：
   - 四大能力概览 2×2：blue / green / orange / purple 各一；
   - 体验设计各主题的洞察 callout：在上述色里轮换，相邻主题不同色；
   - 设计启发 2×2：同样轮换；
   - 收尾 callout：若带 ⚠️ 提醒/短板，用 `light-red`，凸显"提个醒"。
   > ⚠️ 颜色服务于"分区/语气"，不是越花越好——一篇 4–6 种色、同类信息同色即可，别每个 callout 都换到眼花。

4. **截图先裁掉无意义空白边/空白页身再插入。** 整窗截图常带两类无意义空白：(1) 四周**纯色空边**（浏览器外边距、右侧空画布、底部留白）；(2) 内容只占上半屏、**下方一大片空荡荡的页身**（列表只有一行、空态页底部、短 Tab 页）。两类都浪费纵向空间、显松散，插入前用脚本**自动裁掉**：
   - **纯色边框**：PIL 逐行/列判断，某行/列近乎单一颜色（std-dev 近 0）即视为空边，四周内移裁框、留 ~8–12px padding。
   - **下方空白页身（最易漏裁）**：只看**主内容区**（忽略左侧导航栏，即 `x ≥ 侧栏宽`）逐行判空，**裁到"最后一大块连续内容"的底部**——⛔ 不要简单裁到"最后一行非空像素"，因为页底常有零星杂散像素（页脚/侧栏溢出/阴影）会让裁剪失效。正确做法：内容行按"空白间隔 ≥80px 即分块"切成若干块，**丢弃高度 <24px 的杂散小块**，裁到剩下"最后一个大块"的底部。
   - ⚠️ **不要裁产品 UI 内部本就存在的真实留白**（如空态页中央插画周围的留白是真实设计）——"分块 + 保留大块"逻辑天然能保住它（空态插画本身是一个内容块会被保留，只裁它**之后**的纯空白页尾）。
   > 详细做法（含可复用脚本骨架）见 `screenshot-guide.md` 的「插入前裁掉无意义空白边」。

---

## 图片插入说明（经实测验证的可靠流程）

> **实测结论（务必照做）：** 在 `lark-doc docs +create` 这条路径上，**只要 `<img>` 用的是真正的「文档图片素材」`file_token`（`src` 属性），它就能稳定写进文档——包括写进 `<td>` 单元格、写进 `<grid><column>` 分栏**，create 后不丢、能正常渲染。
>
> ⚠️ **换 token 的命令选错 = 整篇图全是乱码（本会话实测的真坑，务必照做）**：换 `file_token` **必须用 `docs +media-insert --type image`**（返回 `{"file_token":"...","type":"image"}` 的**文档图片素材** token，内联进 docx 才能正常渲染）。**⛔ 绝对不要用 `+upload-file`**——它把图传到**云盘 explorer/文件夹**，返回的是**云盘文件 token**，写进 `<img src>` 后飞书会按"云盘文件"而非"图片素材"解析，**整张图显示成乱码/损坏块**（源图本身完好，纯粹是 token 类型错了）。判别：返回里带 `"type":"image"` 才是对的；只有 `"file_token"` 没有 `"type":"image"` 的就是云盘 token，会乱码。
>
> 另一种会丢图的情况：**`<img href="<带签名 query 参数的 URL>">`**——飞书服务端拉不到这种签名图，会被静默丢弃。所以核心是：**先用 `docs +media-insert --type image` 把每张本地图换成图片素材 `file_token`，再用 `<img src="TOKEN">` 一次性写进 create 的 XML。**

### 标准流程：file_token → 内联 `<img src>` → 一次 create

**Step A — 为每张本地图换回「文档图片素材」`file_token`（只此一法）**

把每张本地图 `media-insert` 进一个"临时草稿文档"、并显式指定 `--type image`，借此拿到**可内联渲染的图片素材 token**（返回 JSON 里带 `"type":"image"`）：

```bash
cd <screenshots 目录>            # 用相对路径，绝对路径会报 unsafe file path
<lark-cli> docs +media-insert --doc <SCRATCH_DOC_ID> --type image --file ./00_landing_hero.jpg --caption 00_landing_hero.jpg
# 返回 {"data":{"file_token":"...","type":"image"}} —— 带 "type":"image" 才是对的
```

> ⛔ **不要用 `+upload-file`**：它返回的是云盘文件 token，写进 `<img src>` 会渲染成乱码（见本节顶部「实测结论」）。换 token 一律走 `docs +media-insert --type image`。临时草稿文档随便新建一篇即可（只用来过一遍 media-insert 捕获 token，不影响最终成文）。

> `file_token` 在你（模型）的视图里可能被掩码成占位符——**不要试图肉眼读取/转写**，而是用脚本用正则 `"file_token":\s*"([^"]+)"` 捕获、直接拼进 XML 字符串（见本节末「参考脚本范式」）。

**Step B — 把 `<img src="TOKEN" width=.. height=..>` 直接写进骨架 XML（含单元格 / 分栏），再 `+create`**

> ⚠️ **每个 `<img>` 必须带上图片的真实像素 `width`/`height`（务必，否则点击放大会被拉伸变形）。** 飞书 `<img>` 支持 `width`/`height` 属性；**只给 `src` 不给宽高时，飞书没有原始长宽比信息，用户点击图片放大查看时会把图拉伸成默认框、严重变形**。所以换完 `file_token` 后，用 `PIL.Image.open(path).size` 读出每张图的真实 `(w, h)`，写成 `<img src="TOKEN" width="W" height="H" .../>`。**正文级图、单元格内图、`<grid>` 分栏图都要带宽高，无一例外。**

```xml
<!-- 单元格内单图：必须带真实 width/height -->
<td><p>对话首页空状态：</p><img src="<file_token>" width="1568" height="824" caption="对话空状态首页"/></td>

<!-- 单元格内双图分栏（左、右并排）：每张都带各自的真实宽高 -->
<td>
  <ul><li>说明文字……</li></ul>
  <grid>
    <column width-ratio="0.5"><img src="<token_left>" width="1568" height="616" caption="左：自动化"/></column>
    <column width-ratio="0.5"><img src="<token_right>" width="1568" height="824" caption="右：集成"/></column>
  </grid>
</td>
```

```bash
<lark-cli> docs +create --api-version v2 --content @body.xml
```

- 一个触点要**多张图/多状态**（前/中/后、规划/执行/产物）就在该单元格里连续放多个 `<img>` 或多个 `<grid>`——**图要密**，这是黄金范例的常态（单篇 70+ 图、近九成在单元格内）。
- **宽高取裁剪后图片的真实尺寸（务必）**：图片在插入前已裁掉空白边/页身（见 screenshot-guide.md），所以要读**裁剪后**那张图的 `size`，不是原图——读原图尺寸会让比例错位。标准做法是先批量建一个 `DIM[文件名]=(w,h)` 字典，`img()` 函数据此拼 `width`/`height`：
  ```python
  import os
  from PIL import Image
  SHOTS = "./screenshots_trimmed"          # 裁剪后的图目录
  DIM = {}
  for f in os.listdir(SHOTS):
      if f.lower().endswith((".jpg", ".png", ".gif")):
          with Image.open(os.path.join(SHOTS, f)) as im:
              DIM[f] = im.size                # (w, h) —— 取裁剪后真实像素
  def img(fname, token, cap):                 # token 由正则从上传返回里捕获
      w, h = DIM[fname]
      return f'<img src="{token}" width="{w}" height="{h}" caption="{cap}"/>'
  ```
- GIF 与静态图同样走 `<img src="<file_token>" width=.. height=..>`，飞书原生支持 GIF 播放，宽高同样要带。
- `caption` 写图说，会显示在图下方。

### 参考脚本范式（自包含，可直接复用）

不依赖任何特定会话的旧脚本，按以下流水线自己写一个 `build_doc.py` 即可：

> ⚠️ **开跑前先护 token**：这条流水线是长任务（换 token + create + 画板），按 SKILL.md「Step 4」开头那段先探活/刷新 token，再开始；过程中任一命令报 `99991663` 类过期错，刷新后**原样重跑那条**即可（缓存/节点都还在，⛔ 别改 XML、别重换图）。

1. **建尺寸字典**：扫描 `screenshots_trimmed/`，`DIM[文件名]=PIL.Image.open(图).size`（取**裁剪后**尺寸）。
2. **逐张换图片素材 `file_token`（带重试 + 跳过 + 缓存，⛔ 不要一张失败就崩整批）**：`cd` 到图片目录，对每张图跑 `docs +media-insert --doc <临时草稿> --type image --file ./xxx.jpg`（**必须带 `--type image`，⛔ 不要用 `+upload-file`，否则乱码**），用正则从返回 JSON 里捕获 token。**70+ 张图 = 70+ 次外部调用，必须为稳定性做三件事**：①**单张失败重试 2–3 次**（偶发超时/5xx/空返回很常见）；②**重试仍失败就记进 `failed[]` 跳过、继续后面的图**，最后统一报告——⛔ 不要 `assert` 一刀切中止，否则前面几十张换好的 token 全白费；③**成功的 token 落盘缓存到 `tokens.json`**，create 失败重跑时**先读缓存、已换过的不再重换**（换 token 是要花钱/耗时的外部调用，断点续跑全靠它）。**类型护栏仍在**：返回必须含 `"type":"image"`，否则是云盘 token（用错了 `+upload-file`）→ 当作失败处理：

   ```python
   import re, os, json, time, subprocess

   def _insert_once(cli, scratch, path, cap):
       """换一次 token；成功返回 token，类型不对/没拿到都返回 None。"""
       out = subprocess.run(["bash", cli, "docs", "+media-insert", "--doc", scratch,
                             "--type", "image", "--file", path, "--caption", cap],
                            capture_output=True, text=True).stdout
       m = re.search(r'"file_token":\s*"([^"]+)"', out)
       # 护栏：必须是图片素材 token（含 "type":"image"），否则是云盘 token → 会乱码
       if m and re.search(r'"type":\s*"image"', out):
           return m.group(1)
       return None

   def build_tokens(cli, scratch, files, caches="tokens.json", retries=3, fp=None):
       """files: [文件名,...]（已 cd 到图片目录）。带缓存续跑 + 单张重试 + 失败跳过。
       fp: 产品指纹（如产品名或图片目录绝对路径），防跨产品错配缓存——不传则用当前目录。"""
       fp = fp or os.path.abspath(".")                # ⚠️ 默认用图片目录绝对路径当指纹
       TOK = json.load(open(caches)) if os.path.exists(caches) else {}
       # ⚠️ 产品指纹校验：缓存里的 __fp__ 与本次不一致 = 这是上一个产品的 token，整盘作废重建
       if TOK.get("__fp__") not in (None, fp):
           print(f"⚠️ tokens.json 指纹不匹配（缓存属于「{TOK.get('__fp__')}」，本次是「{fp}」）→ 忽略旧缓存，重新换 token")
           TOK = {}
       TOK["__fp__"] = fp                              # 写入/更新本次指纹
       failed = []
       for fn in files:
           if fn in TOK:                       # ① 缓存命中：已换过，跳过（断点续跑）
               continue
           tok = None
           for i in range(retries):            # ② 单张重试 2–3 次
               tok = _insert_once(cli, scratch, f"./{fn}", fn)
               if tok:
                   break
               time.sleep(1.5 * (i + 1))       # 退避，缓一下再试
           if tok:
               TOK[fn] = tok
               json.dump(TOK, open(caches, "w"), ensure_ascii=False)  # ③ 每成功一张就落盘
           else:
               failed.append(fn)               # 重试仍失败 → 跳过，别崩整批
       if failed:
           print(f"⚠️ 这些图换 token 失败（已跳过，可重跑本函数仅补这些）：{failed}")
           print("   → 多半是偶发超时/限流：直接重跑（缓存会跳过已成功的，只补失败的）；")
           print("   → 若持续失败且返回不含 \"type\":\"image\"，是用错了 +upload-file，检查命令。")
       # 返回前剔除内部指纹键，拼 XML 时 TOK 只剩「文件名→token」
       return {k: v for k, v in TOK.items() if k != "__fp__"}, failed
   ```

   > ⚠️ **`fp` 产品指纹防跨产品错配**：`tokens.json` 按文件名做 key，若分析完 A 产品没清缓存就跑 B 产品，`00_landing_hero.png` 这种通用名会**命中 A 的 token → B 文档里贴出 A 的图**。所以缓存里存了 `__fp__`（产品指纹），换产品时自动判失配并整盘重建——⛔ 不必手动删 `tokens.json`，但**务必给每个产品用独立图片目录**（指纹默认取目录绝对路径，目录一换指纹就变）。

   > 💡 **断点续跑用法**：`build_tokens` 跑完若有 `failed`，**原样再调一次即可**——缓存命中的几十张会瞬间跳过，只重补失败那几张；create 阶段崩了重来同理，token 不必重换。⛔ 失败时不要把整个流程从截图重头再走。
3. **拼骨架 XML**：用 `img(fname, TOK[fname], cap)` 生成 `<img src=TOKEN width=.. height=..>`（单图）或包进 `<grid><column>`（多图分栏），直接写进 `<td>` 单元格。**拼之前先确认 `failed` 为空**（失败的图没 token，硬拼会漏图/错位）——有 `failed` 先重跑补齐再拼。
4. **一次成文**：`docs +create --api-version v2 --content @body.xml`，图随表格落位、不丢。**create 报错（含 token 过期 `99991663` 类）→ 先按系统流程刷新 token / 修 XML，再重跑 create；token 缓存仍在，不必重换图。**

> ⚠️ token 在模型视图里会被掩码成占位符——**全程程序化拼接**（正则捕获 → 字典 → f-string），不要肉眼读取/转写。

> **⛔ 图文错位是头号翻车点（用户反复反馈"图和描述对应不上"），必须从机制上杜绝，不能靠肉眼对齐。** 根因：token 被掩码、文件名又含糊（`05.png` `06.png`）时，"这段文字该配哪张图"全靠人工记忆 → 极易张冠李戴。三条强制做法：
> 1. **文件名即语义锚**：截图阶段就把文件名命成"能一眼看出它是哪个界面/状态"（如 `chat_empty_state.png` `chat_streaming.gif` `chat_done.png`，⛔ 不要 `05.png`）。文档里某段描述配哪张图，**永远靠文件名匹配**，不靠顺序、不靠记忆。
> 2. **描述与图绑成同一个单元格对象，一处定义**：不要在 A 处写描述、B 处填 token。把每个单元格建成 `{"desc": "对话首页空状态：…", "imgs": ["chat_empty_state.png"]}` 这样的对象，`desc` 和 `imgs` 写在一起；渲染时同一对象里 `desc` 出文字、`imgs` 经 `TOK[文件名]` 出 `<img>`，从源头保证"这段话配的就是这张图"。多状态触点 `imgs` 放多张（`<grid>` 并排），顺序＝描述里"前/中/后"的顺序。
> 3. **配对断言（拼 XML 前必跑）**：① 每个 cell 的 `imgs` 里每个文件名都必须在 `TOK`/`DIM` 字典里存在（`assert fn in TOK`），杜绝填了不存在/拼错的文件名；② 所有 `screenshots_trimmed/` 里的图至少被引用一次的反向核对（漏图也是一种错位）；③ 打印一份"文件名 → 它出现在哪个章节/描述"的清单供肉眼复核一眼。
> 4. **⭐ 渲染必须落进 `<td>`，⛔ 描述+图不许散落在表格外（用户反复反馈"散落在外面"）**：`CELLS` 是数据，把它渲染成 XML 时**每个 cell 的 `desc`+`imgs` 必须包在 `<tr><td>…</td></tr>` 里**——⛔ 不要图省事写成 `<p>描述</p><img>` 平铺在表格外。产品功能 / 体验设计两章的每段描述+图，都必须是某张表格里的一行。**拼完 XML、create 之前**先跑一道"散落自检"：统计 `body.xml` 里 `<img>` 总数 vs `<table>…</table>` 内的 `<img>` 数，**两者必须相等**（差额>0 = 有图散落在表格外，回去把散段改成表格行）。

```python
# 单元格 = 描述 + 图 绑死在一起，从源头杜绝错位
CELLS = [
    {"section": "对话三态", "desc": "对话首页空状态：", "imgs": ["chat_empty_state.png"]},
    {"section": "对话三态", "desc": "流式生成中（逐字吐字 + 停止按钮）：", "imgs": ["chat_streaming.gif"]},
    {"section": "对话三态", "desc": "生成完成后的操作条（复制/重试/分享）：", "imgs": ["chat_done.png"]},
]
# 拼 XML 前的配对断言
used = set()
for c in CELLS:
    for fn in c["imgs"]:
        assert fn in TOK, f"❌ 单元格描述「{c['desc']}」引用了不存在的图：{fn}（拼错文件名？）"
        used.add(fn)
unused = set(TOK) - used
assert not unused, f"⚠️ 这些图一张都没被引用（漏配/错位）：{sorted(unused)}"
for c in CELLS:  # 肉眼复核清单：每段描述配了哪张图
    print(f"[{c['section']}] {c['desc']}  ←  {c['imgs']}")

# 复用检测：同一张图被配到多个不同描述点 → 报警，确认是"图里真有这些点"还是"硬凑"
from collections import defaultdict
ref = defaultdict(list)
for c in CELLS:
    for fn in c["imgs"]:
        ref[fn].append(c["desc"])
reused = {fn: ds for fn, ds in ref.items() if len(ds) > 1}
for fn, ds in reused.items():
    print(f"🔁 复用警告：{fn} 被 {len(ds)} 段描述共用 → {ds}")
    print("   ✅ 仅当这张图里确实同时含这些点（并在描述里点明'看图中 X 处/Y 处'）才放行；"
          "❌ 若只是图不够拿它凑数，回去补截专属图。")
# 想强制零复用时可加：assert not reused, "存在硬凑复用，回去补截图"

# ⭐⭐ GIF 缺位自检（防"该录动效却全用静态图"，create 前必跑）
# 背景：GIF 指引全是"优先/尽量"软措辞，没有硬检查 → 模型走捷径全截静态 jpg/png，
#       成文密度自检数总图数照样过（实测翻车：整篇 0 个 GIF）。这里按"描述里的动作词"反推
#       「这条本该是动态过程」，若它配的图里一张 .gif 都没有 → 报警，逼你回 Step 2 补录 GIF。
MOTION_KW = ["流式", "生成中", "逐字", "加载中", "加载态", "hover", "悬浮", "悬停",
             "联想", "弹出", "弹层", "下拉", "切换", "步进", "动效", "动画", "过渡",
             "拖拽", "拖动", "展开", "收起", "轮播", "滚动", "实时", "渐", "浮出", "唤起"]
def _has_gif(c): return any(fn.lower().endswith(".gif") for fn in c["imgs"])
motion_cells = [c for c in CELLS
                if any(k in c["desc"] for k in MOTION_KW) and not _has_gif(c)]
n_gif_total = sum(1 for c in CELLS for fn in c["imgs"] if fn.lower().endswith(".gif"))
if motion_cells:
    print(f"⚠️ GIF 缺位警告：以下 {len(motion_cells)} 条描述含'动作过程'词、却只配了静态图——"
          "本该录成 GIF（飞书原生支持动图播放），回 Step 2 对这些触点重录连续帧→合成 .gif：")
    for c in motion_cells:
        hit = [k for k in MOTION_KW if k in c["desc"]]
        print(f"   - 「{c['desc']}」命中动作词 {hit}，配图 {c['imgs']} 全是静态 → 应有 .gif")
    print("   ✅ 仅当该触点确实无动态变化（如纯静态设置页，动作词只是顺带提及）才可放行；"
          "❌ 若确有动效/流式/弹层却图不会动，就是漏录，必须补 GIF。")
else:
    print(f"✅ GIF 缺位自检通过：含动作词的描述都配了 GIF（全文共 {n_gif_total} 个 GIF）")
# ⚠️ 兜底退化提醒：仅在确认本机无 ffmpeg/Pillow、连续帧也合成不出时，才允许退用"连续多张静态图"
#    并在描述里注明"过程帧"；⛔ 不允许因为"嫌麻烦"跳过录 GIF（那不是环境受限，是偷懒）。

# ⭐⭐ 主题↔台账校验（防"先拍主题再凑内容"的硬关卡，create 前必跑）
# 原理：体验设计章节每个主题引用的截图，都必须在 Step 3 写的 touchpoints.csv 里登记过。
#       若主题是"先拍脑袋想的、再倒着找图圆场"，它引用的图就大概率不在台账里 → assert 崩。
#       这把"先列触点再聚主题"从口号变成机器能验的产出物：跳过台账直接拍主题，这一步就过不去。
import csv, os
TP = "touchpoints.csv"
assert os.path.exists(TP), (
    f"❌ 找不到 {TP}——体验设计动笔前必须先把走查触点写成台账文件（见 analysis-framework.md"
    "「强制两段式」）。没有台账 = 没走「先列触点再聚主题」，回去补。")
with open(TP, encoding="utf-8") as f:
    tp_shots = {row["screenshot"].strip() for row in csv.DictReader(f)}
# 体验设计章节里每个主题用到的截图（CELLS 里 section 标成"体验设计"的那些）
exp_shots = {fn for c in CELLS if "体验设计" in c.get("section", "") for fn in c["imgs"]}
orphan = exp_shots - tp_shots          # 用进了体验设计、却不在台账里的图 = 疑似"凭空冒出的主题"
assert not orphan, (
    f"❌ 体验设计章节这些截图不在 {TP} 台账里：{sorted(orphan)}——"
    "说明对应主题可能是'先定标题再找图凑'的，不是从触点台账聚类涌现的。"
    "回去：要么把它们作为真实触点补进 touchpoints.csv 并重新聚类，要么砍掉该主题。")
print(f"✅ 主题↔台账校验通过：体验设计用到的 {len(exp_shots)} 张图全部登记在 {TP}（共 {len(tp_shots)} 条触点）")

# ⭐ 拼完 body.xml、create 之前必跑：散落自检——所有 <img> 必须在 <table> 内，0 张散落在外
import re as _re
xml = open("body.xml", encoding="utf-8").read()
_total = xml.count("<img")
_in_tbl = sum(t.count("<img") for t in _re.findall(r'<table\b.*?</table>', xml, _re.S))
assert _total == _in_tbl, (
    f"❌ 有 {_total - _in_tbl} 张图散落在表格外（共 {_total} 张，仅 {_in_tbl} 张在 <table> 内）——"
    "产品功能 / 体验设计两章的每段描述+图都必须在同一 <td> 里；把表格外的 <p>描述</p><img> 改成表格行重拼。")
print(f"✅ 散落自检通过：{_total} 张图全部在表格单元格内")
```

### 容错
- create 后整篇图全是乱码/损坏块 → 几乎一定是换 token 时用了 `+upload-file`（云盘 token）而非 `docs +media-insert --type image`（图片素材 token）；回去用 `--type image` 重换、确认返回带 `"type":"image"`。
- create 后某些单元格图没了 → 多半是该 `<img>` 用了 `href="<签名URL>"` 而非 `src="<file_token>"`；回去换成 file_token。
- **图在、但和描述对不上（张冠李戴）** → 没走"描述+图同对象、文件名匹配"那套（见上「图文错位是头号翻车点」）：检查是不是手工把 token 填错单元格、或文件名含糊（`05.png`）靠顺序对齐错位了。回去用语义文件名 + `CELLS` 对象 + 配对断言重拼，⛔ 不靠肉眼/顺序对齐。
- `+media-insert` 报 `unsafe file path` → 没在图片目录里执行，或用了绝对路径；`cd` 到 screenshots 目录用 `./文件名`。
- **换 token 中途某几张失败（超时/限流/空返回）** → `build_tokens` 已把它们记进 `failed[]` 并跳过、不崩整批；**直接原样重跑 `build_tokens` 即可**（`tokens.json` 缓存会跳过已成功的几十张，只补 `failed` 那几张）。⛔ 不要因为几张失败就把整个流程从截图重头再走。
- **create 报 token 过期（`99991663` 类）** → 按系统流程刷新 token 后**重跑 create 即可**；`tokens.json` 仍在，⛔ 不必重换图。
- ⛔ 不要再用「`+media-insert` 按文字锚点逐张补插」这套老办法——它无法把图插进表格单元格（只能定位文档级/块后位置）。**单元格内的图必须在 create 时用 `src=file_token` 写进去。**

---

## 成文后自检脚本（程序化验收，务必跑）

成文后**不要只靠肉眼**判断图有没有丢、密度够不够——`docs +fetch` 把文档回拉下来，用脚本统计实际**落地**的「表格数 / 图片数 / 带图单元格数 / 画板节点数」，再对照 `analysis-framework.md`「图文密度自检」的**分级判定**。图悄悄丢了、密度异常，这一步能立刻抓出来。⚠️ **判定按产品体量分档、只报警不 `assert` 中止**——轻量产品本就该图少，硬卡 60 张会逼你凑数、与"体验设计精选不凑数"打架：

```python
import re, json, subprocess
CLI = "<lark-cli>"                      # lark-doc 的 lark-cli.sh
DOC = "<document_id>"

# ① 先按产品体量选档位（口径见 analysis-framework.md「图文密度自检」分级判定）
#    heavy=多模块/多智能体/复杂工作流；medium=常规产品；light=单页/单功能/体验很短
TIER = "heavy"                         # ← 按本次竞品实际体量改：heavy / medium / light
FLOORS = {                             # (图片下限, 表格下限, 带图单元格下限)
    "heavy":  (60, 5, 12),
    "medium": (30, 3, 8),
    "light":  (12, 2, 4),
}
img_floor, tbl_floor, cell_floor = FLOORS[TIER]

md = subprocess.run(["bash", CLI, "docs", "+fetch", "--doc", DOC],
                    capture_output=True, text=True).stdout

n_img   = len(re.findall(r'!\[', md)) + len(re.findall(r'<img\b', md))   # 落地图片数
n_table = md.count("<table") or md.count("|---")                         # 表格数（xml/markdown 两种回拉形态都兜一下）
# 带图单元格：回拉后单元格里仍带图的 <td>（粗粒度近似，够用来报警）
n_cell  = len(re.findall(r'<td\b[^>]*>(?:(?!</td>).)*?<img', md, re.S))

# ⭐ 散落图检测（用户反复反馈："描述和图散落在表格外"）——这是头号验收项
# 思路：把所有 <table>…</table> 内的图数清点出来，与全文图数对比；差额 = 散落在表格外的图。
tables_html = re.findall(r'<table\b.*?</table>', md, re.S)
n_img_in_table = sum(t.count("<img") for t in tables_html)
n_img_stray = (md.count("<img")) - n_img_in_table        # 注意：markdown 回拉形态见下方说明
print(f"图片总数(<img)={md.count('<img')}  其中在表格内={n_img_in_table}  散落表格外={n_img_stray}")
if n_img_stray > 0:
    print(f"❌ 有 {n_img_stray} 张图散落在表格外（描述/图没进 <td>）——产品功能 / 体验设计两章的"
          "每段描述+图都必须在同一 <td> 单元格里。回去把散段改成表格行重拼，⛔ 不要把 <p>描述</p><img> 平铺在表格外。")
else:
    print("✅ 所有图都在表格单元格内，无散落")
# ⚠️ 若 +fetch 回拉的是 markdown 形态（图是 ![]() 而非 <img>、表格是 |---| 而非 <table>），
#    上面的 <table>/<img> 计数会失真——此时改判：markdown 里图片行若不在 | 表格行 | 内即为散落，
#    或直接 +fetch 时要求 xml 形态再跑本检测。

print(f"[档位={TIER}] 图片={n_img}(≥{img_floor})  表格={n_table}(≥{tbl_floor})  带图单元格≈{n_cell}(≥{cell_floor})")
# ⚠️ 分级"报警"不 assert 中止——低于档位下限只提示排查，由你判断是"漏图"还是"产品本来就轻"
warn = []
if n_img   < img_floor:  warn.append(f"图片仅 {n_img} 张（{TIER} 档下限 {img_floor}）")
if n_table < tbl_floor:  warn.append(f"表格仅 {n_table} 张（{TIER} 档下限 {tbl_floor}）")
if n_cell  < cell_floor: warn.append(f"带图单元格仅 {n_cell} 个（{TIER} 档下限 {cell_floor}）")
if warn:
    print("⚠️ 密度偏低，先排查：" + "；".join(warn))
    print("   → 是不是丢图了（某些 <img> 用错 href / 某状态没截）？修掉漏图。")
    print("   → 还是产品本来就轻、每个亮点都已配齐图？是则放行，⛔ 不要为凑数硬塞重复/无关图。")
else:
    print("✅ 图文密度达标（已按档位判定）")

# 复用率核对（防硬凑）：回拉后统计同一 file_token 被引用几次，高复用 = 疑似拿同图凑多处描述
from collections import Counter
toks = re.findall(r'<img\b[^>]*\bsrc="([^"]+)"', md)
dup = {t: c for t, c in Counter(toks).items() if c > 1}
if dup:
    print(f"🔁 疑似图片复用（同一张图出现多次）：{ {t[:8]+'…': c for t, c in dup.items()} }")
    print("   ✅ 仅当这张图确实同时承载多个描述点、且描述已点明'看图中 X 处/Y 处'才放行；"
          "❌ 若是图不够硬凑，回去补截专属图。")
else:
    print("✅ 无图片复用，图与描述一一对应")
```

> **画板节点数另算**（确认时间线是否干净注入、有没有叠两份）：`whiteboard +query --whiteboard-token <tok> --output_as raw --format json` → 读 `data.nodes` 长度，应等于 SVG 转 openapi 的节点数（如 6 里程碑 ≈31）；显著大于（如翻倍）说明叠加了，删板重做。
> ⚠️ 档位下限是**报警阈值不是上限、也不是硬卡**——先按产品体量选对 `TIER`，低于下限**先排查"是不是丢图了"**（多半是某些 `<img>` 用错 `href`），确认产品本来就轻、每个亮点都配齐了图就放行；⛔ 不要为凑一个数字硬塞重复/无关图（与「体验设计精选不凑数」一致）。
